recipes FE - add , sort and create recipe book with photo, title, ingredients and preparation instructions !
images created with AI
translate to ANY LANG with AI
keep images on BE
BE in VERCEL node.js express
